import { getUsersSerice } from '../services/user-service.js';
import { serverInstance } from '../index.js';

export const getUsers = async (request, h) => {
    try {
        const response = await getUsersSerice();
        const content = await serverInstance.render('welcome'); // render kontennya dulu
        return h.view('layouts/main',{
            title: 'Welcome',
            body: content,
            users: response.data 
    }).code(200)
    } catch (error) {
        console.error('Error fetching users:', error);
        return h.response({ message: 'Could not fetch users' }).code(500);
        
    }
};
