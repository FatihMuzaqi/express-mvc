import { getUsers } from "../controllers/user-controller.js";

const routeUser = [
    {
        method: 'GET',
        path: '/',
        handler: getUsers
    },
]

export default routeUser;