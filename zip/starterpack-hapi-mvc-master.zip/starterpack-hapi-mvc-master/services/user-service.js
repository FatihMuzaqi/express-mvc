import Users from '../models/user-model.js';

export const getUsersSerice = () => {
    try {
        const data = Users.findAll();
        return data;
    } catch (error) {
        console.error('Error fetching users:', error);
        throw new Error('Could not fetch users');
        
    }
}
