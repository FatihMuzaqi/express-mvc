1. git clone:

````
git clone https://github.com/FatihMuzaqi/starterpack-hapi-mvc.git
````

2. Masuk ke direktori 
````

cd starterpack-hapi-mvc
````

3. Instal node module
````
npm install
````

4.Copy env
````
cp .env.example .env
````

5. Jalankan server
````
node index.js
````