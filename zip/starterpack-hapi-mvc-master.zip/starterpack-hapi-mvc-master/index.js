'use strict';

import Hapi from '@hapi/hapi';
import Inert from '@hapi/inert';
import Users from './models/user-model.js';
import routeUser from './routes/user-route.js';
import Ejs from 'ejs';
import Path from 'path';
import Vision from '@hapi/vision';
import db from './configs/db.js';

let serverInstance;

const init = async () => { 

    const server = Hapi.server({
        port: 3000,
        host: 'localhost'
    });

    await server.register(Vision);
    await server.register(Inert);

    server.route({
        method: 'GET',
        path: '/{param*}',
        handler: {
            directory: {
            path: Path.resolve('public'),
            listing: false,
            index: false
            }
        }
});

server.views({
        engines: { ejs: Ejs }, // Pakai variabel Ejs dari import
        relativeTo: Path.resolve(),
        path: 'views' // Folder tempat file .ejs
    });


    server.route(routeUser);


    await server.start();
    serverInstance = server; 
    console.log('Server running on %s', server.info.uri);

};

try {
        await db.authenticate();
        console.log('Database Connected...');
        await Users.sync();
    } catch (error) {
        
    }

process.on('unhandledRejection', (err) => {

    console.log(err);
    process.exit(1);
});

export { serverInstance };

init();